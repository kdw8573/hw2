import React from 'react'
import LoginOrganism  from '../../../containers/LoginOrganism'

const HomePage = () => {
  return (
    <div>
      <LoginOrganism />
    </div>
  )
}

export default HomePage
