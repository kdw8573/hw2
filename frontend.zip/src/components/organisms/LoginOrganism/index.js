//import React, { PropTypes } from 'react'
import React from 'react'
import PropTypes from 'prop-types';
import styled from 'styled-components'
import { font, palette } from 'styled-theme'
import Button from '../../atoms/Button'
import Meeting from '../../atoms/Meeting'

const Wrapper = styled.div`
  font-family: ${font('primary')};
  color: ${palette('grayscale', 0)};
  div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
  }
`

export const LoginOrganism = ({state, onLoginRequest, onLogoutRequest}) => {
  let uid, upwd
  if(state.meeting.token == null) {
    return (
          <div>
            <div>
              <div>
              <h2>Id</h2>
              <input id="username_field" ref={node => {uid = node;}}/>
              </div>
              <div>
              <h2>Password</h2>
              <input id="password_field" ref={node => {upwd = node;}}/>
              </div>
            </div>
            <br></br>
            <Button type="submit" onClick={() => onLoginRequest(uid.value, upwd.value)}>login</Button>
          </div>
        )
    }
    else {
      let arr = JSON.parse(state.meeting.mlist)
      return (
          <div>
            <h2> Username: {state.meeting.username}</h2>
            <Button type="submit" onClick={() => onLogoutRequest()}>Logout</Button>
            <div>
               {arr.map(element => <Meeting key = {element.id} {...element}/>)}
            </div>
          </div>
        )
    }



}

LoginOrganism.propTypes = {
  reverse: PropTypes.bool,
}

export default LoginOrganism
