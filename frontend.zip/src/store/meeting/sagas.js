//import { take, put, call, fork, spawn, select } from 'redux-saga/effects'
//import { delay } from 'redux-saga'
//import api from 'services/api'
//import { getMeeting } from './selectors'
//import * as actions from './actions'
// import { loginSuccess, loginFailure } from 'store/actions'

import {take, put, call, fork} from 'redux-saga/effects'
import api from 'services/api'
import * as actions from './actions'

const url = 'http://127.0.0.1:8000/meetings/'

export function* watchLogin() {
	while(true) {
		const data = yield take(actions.LOGIN_REQUEST)
		yield call(loginReq, data)
	}
}

export function* loginReq(data) {
  let uname = data.username
	let upwd = data.password
	const hash = new Buffer(`${uname}:${upwd}`).toString('base64')
	const response = yield call(fetch, url, {
		method: 'GET',
		headers: {
			'Authorization': `Basic ${hash}`
		}
	})
	console.log(response)
	const mlist = yield call([response, response.json])

	if (!response.ok) {
		console.log("Login Failure")
		yield put(actions.loginFailure())
	} else {
		console.log("Login Success")
		yield put(actions.loginSuccess(uname, upwd, mlist))
	}
}

export default function* () {
  yield fork(watchLogin)
}
