export const initialState = {
  username : localStorage.getItem("username"),
  password: '',
  token: localStorage.getItem("token"),
  isAuthenticated: false,
  isLoading: true,
  errors : {},
  mlist: localStorage.getItem("mlist"),
  sinceWhen: '',
  tilWhen: ''
};

export const getMeeting = (state) => (state.meeting)
