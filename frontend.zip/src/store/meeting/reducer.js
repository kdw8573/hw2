import { initialState } from "./selectors";

const login = (state = initialState, action) => {
	// console.log('##### login reducer #####')
	// console.log(action)
  switch (action.type) {

    case 'LOGIN_SUCCESS':
			localStorage.setItem("token", action.data.username);
      localStorage.setItem("username", action.data.username);
      localStorage.setItem("mlist", JSON.stringify(action.data.mlist));
      return{
          ...state,
          ...action.data,
          username: action.data.username,
          token: action.data.username,
          isAuthenticated: true,
          isLoading: false,
          errors: null,
          mlist: JSON.stringify(action.data.mlist)
      }

    case 'LOGIN_ERROR':
			localStorage.removeItem("token");
      localStorage.removeItem("mlist");
      alert('Login Fail')
			return {...state, errors: action.data, token: null, username: null,
			     isAuthenticated: false, isLoading: false}

    case 'LOGOUT_SUCCESS':
			localStorage.removeItem("token");
      localStorage.removeItem("mlist");
			return {...state,
      ...action.data,
      username:'',
      password: '',
      token: null,
      isAuthenticated: false,
      isLoading: false,
      errors: null
    }

    case 'LOGOUT_REQUEST':
      localStorage.removeItem("token");
      localStorage.removeItem("mlist");
      return {
        ...state,
        ...action.data,
        username:'',
        password: '',
        token: null,
        isAuthenticated: false,
        isLoading: false,
        errors: null
      }
    default:
      return state
  }
}

export default login
