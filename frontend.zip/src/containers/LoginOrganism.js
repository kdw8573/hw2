import React from 'react'
import { connect } from 'react-redux'
import { loginRequest ,logoutRequest} from '../store/meeting/actions'
import { LoginOrganism } from '../components/organisms/LoginOrganism'

const mapStateToProps = (state) => {
	return {
		state: state
	}
}

const mapDispatchToProps = (dispatch) => {
	return {
		onLoginRequest: (username, password) => {
			dispatch(loginRequest(username, password))
		},
		onLogoutRequest: () => {
			dispatch(logoutRequest())
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginOrganism)
